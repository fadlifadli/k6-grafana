This directory is intended to host images for use in GitHub markdown files.
