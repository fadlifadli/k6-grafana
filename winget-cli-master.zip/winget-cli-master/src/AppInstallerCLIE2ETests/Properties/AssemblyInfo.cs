﻿// -----------------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="Microsoft Corporation">
//     Copyright (c) Microsoft Corporation. Licensed under the MIT License.
// </copyright>
// -----------------------------------------------------------------------------

[assembly: System.Runtime.Versioning.SupportedOSPlatform("windows10.0.17763")]
