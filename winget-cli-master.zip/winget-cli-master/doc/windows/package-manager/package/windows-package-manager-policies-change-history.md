# Change history for Microsoft Store Policies

| Date | Document Version | Change Description |
|------|------------------|--------------------|
| 5/25/2021 | 1.0 | Initial publishing of Windows Package Manager Policies|
